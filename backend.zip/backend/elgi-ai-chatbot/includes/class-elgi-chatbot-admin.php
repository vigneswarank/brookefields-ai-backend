<?php
/**
 * Admin Settings Class
 * Provides the WordPress admin configuration panel for the ELGi AI chatbot.
 */

defined('ABSPATH') || exit;

class Elgi_Chatbot_Admin {

    private const MENU_SLUG = 'elgi-ai-chatbot';
    private const OPTION_GROUP = 'elgi_chatbot_options';

    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_filter('plugin_action_links_' . plugin_basename(ELGI_CHATBOT_PLUGIN_DIR . 'elgi-ai-chatbot.php'),
            [$this, 'add_settings_link']);
    }

    public function add_admin_menu(): void {
        add_options_page(
            __('ELGi AI Chatbot Settings', 'elgi-ai-chatbot'),
            __('ELGi AI Chatbot', 'elgi-ai-chatbot'),
            'manage_options',
            self::MENU_SLUG,
            [$this, 'render_settings_page']
        );
    }

    public function register_settings(): void {
        // Register all settings
        $settings = [
            'elgi_chatbot_enabled'          => ['default' => '1',    'sanitize' => 'absint'],
            'elgi_chatbot_api_url'          => ['default' => '',     'sanitize' => 'esc_url_raw'],
            'elgi_chatbot_site_id'          => ['default' => '',     'sanitize' => 'sanitize_text_field'],
            'elgi_chatbot_api_key'          => ['default' => '',     'sanitize' => 'sanitize_text_field'],
            'elgi_chatbot_load_pages'       => ['default' => 'all',  'sanitize' => 'sanitize_text_field'],
            'elgi_chatbot_specific_pages'   => ['default' => [],     'sanitize' => [$this, 'sanitize_array_of_ints']],
            'elgi_chatbot_exclude_pages'    => ['default' => [],     'sanitize' => [$this, 'sanitize_array_of_ints']],
            'elgi_chatbot_custom_css'       => ['default' => '',     'sanitize' => 'wp_strip_all_tags'],
        ];

        foreach ($settings as $key => $config) {
            register_setting(self::OPTION_GROUP, $key, [
                'sanitize_callback' => $config['sanitize'],
                'default'           => $config['default'],
            ]);
        }

        // Section: Connection
        add_settings_section('elgi_connection_section', __('API Connection', 'elgi-ai-chatbot'),
            [$this, 'render_connection_section_desc'], self::MENU_SLUG);

        add_settings_field('elgi_chatbot_api_url', __('AI Backend URL', 'elgi-ai-chatbot'),
            [$this, 'render_api_url_field'], self::MENU_SLUG, 'elgi_connection_section');

        add_settings_field('elgi_chatbot_site_id', __('Site ID', 'elgi-ai-chatbot'),
            [$this, 'render_site_id_field'], self::MENU_SLUG, 'elgi_connection_section');

        add_settings_field('elgi_chatbot_api_key', __('Widget API Key', 'elgi-ai-chatbot'),
            [$this, 'render_api_key_field'], self::MENU_SLUG, 'elgi_connection_section');

        // Section: Display
        add_settings_section('elgi_display_section', __('Display Settings', 'elgi-ai-chatbot'),
            null, self::MENU_SLUG);

        add_settings_field('elgi_chatbot_enabled', __('Enable Chatbot', 'elgi-ai-chatbot'),
            [$this, 'render_enabled_field'], self::MENU_SLUG, 'elgi_display_section');

        add_settings_field('elgi_chatbot_load_pages', __('Show On', 'elgi-ai-chatbot'),
            [$this, 'render_load_pages_field'], self::MENU_SLUG, 'elgi_display_section');

        add_settings_field('elgi_chatbot_custom_css', __('Custom CSS', 'elgi-ai-chatbot'),
            [$this, 'render_custom_css_field'], self::MENU_SLUG, 'elgi_display_section');
    }

    // ── Field Renderers ────────────────────────────────────────

    public function render_connection_section_desc(): void {
        echo '<p class="description">' . esc_html__(
            'Connect this WordPress site to your centralized ELGi AI backend. All AI processing happens server-side — no API keys exposed to visitors.',
            'elgi-ai-chatbot'
        ) . '</p>';
    }

    public function render_api_url_field(): void {
        $value = esc_attr(get_option('elgi_chatbot_api_url', 'https://ai.elgi.com'));
        echo '<input type="url" name="elgi_chatbot_api_url" value="' . $value . '" class="regular-text" placeholder="https://ai.elgi.com" />';
        echo '<p class="description">' . esc_html__('Your centralized FastAPI backend URL.', 'elgi-ai-chatbot') . '</p>';
    }

    public function render_site_id_field(): void {
        $value = esc_attr(get_option('elgi_chatbot_site_id', ''));
        echo '<input type="text" name="elgi_chatbot_site_id" value="' . $value . '" class="regular-text" placeholder="elgi-us" />';
        echo '<p class="description">' . esc_html__('Unique identifier for this website (e.g., elgi-us, elgi-in, elgi-eu). Used for multi-tenant routing.', 'elgi-ai-chatbot') . '</p>';
    }

    public function render_api_key_field(): void {
        $value = esc_attr(get_option('elgi_chatbot_api_key', ''));
        echo '<input type="password" name="elgi_chatbot_api_key" value="' . $value . '" class="regular-text" autocomplete="new-password" />';
        echo '<p class="description">' . esc_html__('Public widget API key (read-only permissions only). Stored server-side, NOT exposed in page source.', 'elgi-ai-chatbot') . '</p>';
    }

    public function render_enabled_field(): void {
        $enabled = get_option('elgi_chatbot_enabled', '1');
        echo '<label><input type="checkbox" name="elgi_chatbot_enabled" value="1" ' . checked('1', $enabled, false) . ' /> ';
        echo esc_html__('Enable the AI chatbot on this website', 'elgi-ai-chatbot') . '</label>';
    }

    public function render_load_pages_field(): void {
        $value = get_option('elgi_chatbot_load_pages', 'all');
        $options = [
            'all'       => __('All pages', 'elgi-ai-chatbot'),
            'specific'  => __('Specific pages only', 'elgi-ai-chatbot'),
            'exclude'   => __('All pages except specific', 'elgi-ai-chatbot'),
        ];
        echo '<select name="elgi_chatbot_load_pages">';
        foreach ($options as $key => $label) {
            echo '<option value="' . esc_attr($key) . '" ' . selected($value, $key, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select>';
    }

    public function render_custom_css_field(): void {
        $value = esc_textarea(get_option('elgi_chatbot_custom_css', ''));
        echo '<textarea name="elgi_chatbot_custom_css" rows="6" class="large-text code" placeholder="/* Override widget styles */">' . $value . '</textarea>';
        echo '<p class="description">' . esc_html__('Add custom CSS to override widget styles (e.g., adjust position, colors).', 'elgi-ai-chatbot') . '</p>';
    }

    // ── Settings Page Renderer ─────────────────────────────────

    public function render_settings_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die(__('Insufficient permissions', 'elgi-ai-chatbot'));
        }

        // Connection test result
        $test_result = null;
        if (isset($_POST['elgi_test_connection']) && check_admin_referer('elgi_test_connection_nonce')) {
            $test_result = $this->test_api_connection();
        }
        ?>
        <div class="wrap">
          <h1>
            <span style="color:#E63329">▶</span> 
            <?php esc_html_e('ELGi AI Chatbot Settings', 'elgi-ai-chatbot'); ?>
          </h1>

          <?php if ($test_result !== null): ?>
            <div class="notice notice-<?php echo $test_result['success'] ? 'success' : 'error'; ?> is-dismissible">
              <p><?php echo esc_html($test_result['message']); ?></p>
            </div>
          <?php endif; ?>

          <div style="display:grid; grid-template-columns: 1fr 320px; gap: 24px; margin-top: 20px;">
            
            <div>
              <form method="post" action="options.php">
                <?php
                  settings_fields(self::OPTION_GROUP);
                  do_settings_sections(self::MENU_SLUG);
                  submit_button(__('Save Settings', 'elgi-ai-chatbot'));
                ?>
              </form>
            </div>

            <!-- Sidebar -->
            <div>
              <!-- Status Card -->
              <div class="elgi-admin-card">
                <h3><?php esc_html_e('🔌 Connection Status', 'elgi-ai-chatbot'); ?></h3>
                <?php $this->render_status_indicator(); ?>
                <form method="post" style="margin-top: 12px;">
                  <?php wp_nonce_field('elgi_test_connection_nonce'); ?>
                  <input type="submit" name="elgi_test_connection" value="<?php esc_attr_e('Test Connection', 'elgi-ai-chatbot'); ?>" class="button button-secondary" />
                </form>
              </div>

              <!-- Quick Start -->
              <div class="elgi-admin-card" style="margin-top: 16px;">
                <h3><?php esc_html_e('🚀 Quick Start', 'elgi-ai-chatbot'); ?></h3>
                <ol style="margin-left: 16px; line-height: 1.8;">
                  <li><?php esc_html_e('Enter your Backend URL', 'elgi-ai-chatbot'); ?></li>
                  <li><?php esc_html_e('Set a unique Site ID', 'elgi-ai-chatbot'); ?></li>
                  <li><?php esc_html_e('Enter your Widget API Key', 'elgi-ai-chatbot'); ?></li>
                  <li><?php esc_html_e('Save & Test Connection', 'elgi-ai-chatbot'); ?></li>
                  <li><?php esc_html_e('Visit your site — chatbot appears!', 'elgi-ai-chatbot'); ?></li>
                </ol>
              </div>

              <!-- Widget Embed Code -->
              <div class="elgi-admin-card" style="margin-top: 16px;">
                <h3><?php esc_html_e('📋 Manual Embed Code', 'elgi-ai-chatbot'); ?></h3>
                <p style="font-size: 12px; color: #666;"><?php esc_html_e('For non-WordPress sites, add to footer:', 'elgi-ai-chatbot'); ?></p>
                <?php
                $api_url = get_option('elgi_chatbot_api_url', 'https://ai.elgi.com');
                $site_id = get_option('elgi_chatbot_site_id', 'your-site-id');
                $embed_code = '<script src="' . esc_url($api_url) . '/widget/elgi-chat-widget.js" data-site-id="' . esc_attr($site_id) . '" defer></script>';
                ?>
                <textarea readonly class="code" style="width:100%;height:80px;font-size:11px;"><?php echo esc_html($embed_code); ?></textarea>
              </div>
            </div>
          </div>
        </div>

        <style>
          .elgi-admin-card {
            background: white;
            border: 1px solid #e2e4e7;
            border-radius: 8px;
            padding: 16px 20px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.04);
          }
          .elgi-admin-card h3 { margin: 0 0 12px; font-size: 14px; }
        </style>
        <?php
    }

    private function render_status_indicator(): void {
        $api_url = get_option('elgi_chatbot_api_url', '');
        $site_id = get_option('elgi_chatbot_site_id', '');
        $api_key = get_option('elgi_chatbot_api_key', '');
        $enabled = get_option('elgi_chatbot_enabled', '1');

        $configured = !empty($api_url) && !empty($site_id) && !empty($api_key);
        $status_color = ($configured && $enabled) ? '#34C759' : '#FF9500';
        $status_text  = $configured 
            ? ($enabled ? __('Active', 'elgi-ai-chatbot') : __('Disabled', 'elgi-ai-chatbot'))
            : __('Not Configured', 'elgi-ai-chatbot');

        echo '<div style="display:flex;align-items:center;gap:8px;">';
        echo '<span style="width:12px;height:12px;border-radius:50%;background:' . esc_attr($status_color) . ';display:inline-block;"></span>';
        echo '<strong>' . esc_html($status_text) . '</strong>';
        echo '</div>';

        if (!$configured) {
            echo '<p style="color:#666;font-size:12px;margin-top:8px;">' . esc_html__('Please fill in API URL, Site ID, and API Key.', 'elgi-ai-chatbot') . '</p>';
        }
    }

    private function test_api_connection(): array {
        $api_url = get_option('elgi_chatbot_api_url', '');
        if (empty($api_url)) {
            return ['success' => false, 'message' => __('API URL is not configured.', 'elgi-ai-chatbot')];
        }

        $response = wp_remote_get(trailingslashit($api_url) . 'health/', [
            'timeout' => 10,
            'headers' => ['User-Agent' => 'ELGi-WordPress-Plugin/' . ELGI_CHATBOT_VERSION],
        ]);

        if (is_wp_error($response)) {
            return ['success' => false, 'message' => sprintf(
                __('Connection failed: %s', 'elgi-ai-chatbot'),
                $response->get_error_message()
            )];
        }

        $code = wp_remote_retrieve_response_code($response);
        if ($code === 200) {
            return ['success' => true, 'message' => __('✅ Connection successful! Your AI backend is reachable.', 'elgi-ai-chatbot')];
        }

        return ['success' => false, 'message' => sprintf(
            __('Unexpected response code: %d. Check your backend URL.', 'elgi-ai-chatbot'), $code
        )];
    }

    public function enqueue_admin_assets(string $hook): void {
        if ('settings_page_' . self::MENU_SLUG !== $hook) return;
        // Minimal admin styles handled inline above
    }

    public function add_settings_link(array $links): array {
        $settings_link = '<a href="' . admin_url('options-general.php?page=' . self::MENU_SLUG) . '">' .
            __('Settings', 'elgi-ai-chatbot') . '</a>';
        array_unshift($links, $settings_link);
        return $links;
    }

    public function sanitize_array_of_ints($value): array {
        if (!is_array($value)) return [];
        return array_map('absint', $value);
    }
}
