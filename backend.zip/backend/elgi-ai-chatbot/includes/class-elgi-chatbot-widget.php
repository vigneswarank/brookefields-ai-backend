<?php
/**
 * Widget Injection Class
 * Handles frontend widget loading — injects the JS widget into WordPress pages.
 * NO heavy AI logic here. WordPress only loads the lightweight widget JS.
 */

defined('ABSPATH') || exit;

class Elgi_Chatbot_Widget {

    public function inject_widget(): void {
        // Check if enabled
        if (!get_option('elgi_chatbot_enabled', '1')) return;

        // Validate config
        $api_url = get_option('elgi_chatbot_api_url', '');
        $site_id = get_option('elgi_chatbot_site_id', '');
        $api_key = get_option('elgi_chatbot_api_key', '');

        if (empty($api_url) || empty($site_id) || empty($api_key)) {
            // Show admin notice if on frontend and user is admin
            if (is_user_logged_in() && current_user_can('manage_options')) {
                echo '<!-- ELGi AI Chatbot: Not configured. Please visit Settings > ELGi AI Chatbot -->';
            }
            return;
        }

        // Check page targeting rules
        if (!$this->should_show_on_current_page()) return;

        $widget_url = trailingslashit(esc_url($api_url)) . 'widget/elgi-chat-widget.js';
        $custom_css = get_option('elgi_chatbot_custom_css', '');

        ?>
        <?php if (!empty($custom_css)): ?>
        <style id="elgi-chatbot-custom">
          <?php echo wp_strip_all_tags($custom_css); ?>
        </style>
        <?php endif; ?>

        <script
          id="elgi-ai-chatbot"
          src="<?php echo esc_url($widget_url); ?>"
          data-site-id="<?php echo esc_attr($site_id); ?>"
          data-api-key="<?php echo esc_attr($api_key); ?>"
          defer
        ></script>
        <?php
    }

    public function maybe_enqueue_assets(): void {
        // Reserved for future use — e.g., preconnect hints for performance
        if (!get_option('elgi_chatbot_enabled', '1')) return;
        
        $api_url = get_option('elgi_chatbot_api_url', '');
        if (empty($api_url)) return;

        // Add DNS prefetch for the AI backend domain
        add_action('wp_head', function() use ($api_url) {
            $parsed = parse_url($api_url);
            if (!empty($parsed['host'])) {
                echo '<link rel="dns-prefetch" href="//' . esc_attr($parsed['host']) . '" />' . "\n";
                echo '<link rel="preconnect" href="' . esc_url($api_url) . '" crossorigin />' . "\n";
            }
        });
    }

    /**
     * Determine if the chatbot should appear on the current page
     * based on admin page targeting settings.
     */
    private function should_show_on_current_page(): bool {
        $load_rule = get_option('elgi_chatbot_load_pages', 'all');

        if ($load_rule === 'all') {
            return true;
        }

        $current_page_id = get_the_ID();

        if ($load_rule === 'specific') {
            $specific_pages = (array) get_option('elgi_chatbot_specific_pages', []);
            return in_array($current_page_id, $specific_pages, true);
        }

        if ($load_rule === 'exclude') {
            $excluded_pages = (array) get_option('elgi_chatbot_exclude_pages', []);
            return !in_array($current_page_id, $excluded_pages, true);
        }

        return true;
    }
}
