<?php
/**
 * Plugin Name:       ELGi AI Chatbot
 * Plugin URI:        https://www.elgi.com
 * Description:       Embeds the ELGi AI-powered chatbot widget using centralized RAG backend. No heavy server-side logic — just injects the smart widget.
 * Version:           1.0.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            ELGi Equipments Ltd.
 * Author URI:        https://www.elgi.com
 * License:           GPL v2 or later
 * Text Domain:       elgi-ai-chatbot
 * Domain Path:       /languages
 */

// Prevent direct access
defined('ABSPATH') || exit;

define('ELGI_CHATBOT_VERSION', '1.0.0');
define('ELGI_CHATBOT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ELGI_CHATBOT_PLUGIN_URL', plugin_dir_url(__FILE__));

// Load includes
require_once ELGI_CHATBOT_PLUGIN_DIR . 'includes/class-elgi-chatbot-admin.php';
require_once ELGI_CHATBOT_PLUGIN_DIR . 'includes/class-elgi-chatbot-widget.php';

/**
 * Main plugin class
 */
class Elgi_AI_Chatbot {

    private static ?Elgi_AI_Chatbot $instance = null;

    public static function get_instance(): Elgi_AI_Chatbot {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks(): void {
        // Admin
        if (is_admin()) {
            new Elgi_Chatbot_Admin();
        }

        // Frontend widget injection
        $widget = new Elgi_Chatbot_Widget();
        add_action('wp_footer', [$widget, 'inject_widget']);
        add_action('wp_enqueue_scripts', [$widget, 'maybe_enqueue_assets']);

        // Plugin lifecycle
        register_activation_hook(__FILE__, [$this, 'on_activate']);
        register_deactivation_hook(__FILE__, [$this, 'on_deactivate']);
        register_uninstall_hook(__FILE__, [__CLASS__, 'on_uninstall']);
    }

    public function on_activate(): void {
        // Set default options on activation
        $defaults = [
            'elgi_chatbot_enabled'      => '1',
            'elgi_chatbot_api_url'      => 'https://ai.elgi.com',
            'elgi_chatbot_site_id'      => '',
            'elgi_chatbot_api_key'      => '',
            'elgi_chatbot_load_pages'   => 'all',
            'elgi_chatbot_specific_pages' => [],
            'elgi_chatbot_exclude_pages'  => [],
            'elgi_chatbot_custom_css'   => '',
        ];

        foreach ($defaults as $key => $value) {
            if (false === get_option($key)) {
                add_option($key, $value);
            }
        }

        // Store activation time
        update_option('elgi_chatbot_activated_at', current_time('mysql'));
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }

    public function on_deactivate(): void {
        flush_rewrite_rules();
    }

    public static function on_uninstall(): void {
        // Clean up ALL plugin data on uninstall
        $options = [
            'elgi_chatbot_enabled',
            'elgi_chatbot_api_url',
            'elgi_chatbot_site_id',
            'elgi_chatbot_api_key',
            'elgi_chatbot_load_pages',
            'elgi_chatbot_specific_pages',
            'elgi_chatbot_exclude_pages',
            'elgi_chatbot_custom_css',
            'elgi_chatbot_activated_at',
        ];
        foreach ($options as $option) {
            delete_option($option);
        }
    }
}

// Bootstrap
Elgi_AI_Chatbot::get_instance();
