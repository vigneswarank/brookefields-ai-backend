=== ELGi AI Chatbot ===
Contributors: elgi-dev
Requires at least: 5.8
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-powered chatbot for ELGi air compressor websites. RAG-based product assistant with brochure delivery and CRM integration.

== Description ==

The ELGi AI Chatbot plugin embeds a smart AI assistant on your WordPress website. The chatbot helps industrial buyers discover air compressor products, retrieve technical specifications, and request product brochures.

**Architecture:**
- All AI processing happens in a centralized backend (FastAPI + OpenAI + Supabase)
- WordPress only loads a lightweight JavaScript widget (~15KB gzipped)
- No API keys stored in WordPress
- Works across unlimited ELGi websites with multi-tenant routing

**Features:**
- Floating sticky chatbot (bottom-right corner)
- RAG-based product search (retrieves real specs from your documents)
- Brochure request with email capture
- GDPR-compliant lead management
- CRM integration (HubSpot, Salesforce, custom)
- Custom branding per website
- Page targeting (show on all pages, specific pages, or exclude pages)

== Installation ==

1. Upload `elgi-ai-chatbot` folder to `/wp-content/plugins/`
2. Activate the plugin through **Plugins** menu in WordPress
3. Go to **Settings → ELGi AI Chatbot**
4. Enter your Backend URL, Site ID, and Widget API Key
5. Click **Test Connection** to verify
6. Save — the chatbot appears on your site immediately!

== Frequently Asked Questions ==

= Does this plugin store user conversations in WordPress? =
No. All conversations are logged in the centralized AI backend database.

= Is it GDPR compliant? =
Yes. Email capture requires explicit GDPR consent. IP addresses are SHA-256 hashed before storage.

= Can I use this on multiple WordPress sites? =
Yes — each site gets a unique Site ID that routes to site-specific product data and CRM.

= What if the AI backend goes down? =
The widget shows a graceful fallback message directing users to contact support@elgi.com.

== Changelog ==

= 1.0.0 =
* Initial release
